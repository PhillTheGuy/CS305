package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Formatter;
import java.util.Map;

/* Phillip Kimbrel
*/

@SpringBootApplication
@RestController
public class SslServerApplication {

	private static final byte[] KEY = "MySecretKey12345".getBytes(); // 16 bytes = AES-128
    private static final String VERIFIED_BY = "Phillip Kimbrel";

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
    @GetMapping("/hash")
    public Map<String, String> generateSecureHash() throws Exception {
        String data = "Hello World" + System.currentTimeMillis();
        String encrypted = encryptAES(data);
        String sha256 = generateSHA256(data);

        return Map.of(
            "input", data,
            "encrypted", encrypted,
            "sha256", sha256,
            "verifiedBy", VERIFIED_BY
        );
    }
    
    private String encryptAES(String data) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        SecretKeySpec keySpec = new SecretKeySpec(KEY, "AES");
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        return Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes("UTF-8")));
    }

    private String generateSHA256(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(input.getBytes("UTF-8"));
        Formatter formatter = new Formatter();
        for (byte b : hash) formatter.format("%02x", b);
        String hex = formatter.toString();
        formatter.close();
        return hex;
    }
}


	